//*****************************************************************************
// pinmux.h
//
// Pin configuration entry point for the final cloud security node project.
//*****************************************************************************

#ifndef PINMUX_H_
#define PINMUX_H_

extern void PinMuxConfig(void);

#endif /* PINMUX_H_ */
