//*****************************************************************************
// Integrated CC3200 security node firmware.
//*****************************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#include "simplelink.h"

#include "hw_types.h"
#include "hw_ints.h"
#include "hw_memmap.h"
#include "rom.h"
#include "rom_map.h"
#include "interrupt.h"
#include "prcm.h"
#include "gpio.h"
#include "systick.h"
#include "spi.h"
#include "utils.h"

#include "pinmux.h"
#include "gpio_if.h"
#include "common.h"
#include "uart_if.h"
#include "i2c_if.h"
#include "Adafruit_GFX.h"
#include "Adafruit_SSD1351.h"
#include "utils/network_utils.h"

#define APPLICATION_VERSION         "1.0.final"

#define DATE                        9
#define MONTH                       3
#define YEAR                        2026
#define HOUR                        22
#define MINUTE                      0
#define SECOND                      0

#define SERVER_NAME                 "a2cog51vdwl2c1-ats.iot.us-east-2.amazonaws.com"
#define GOOGLE_DST_PORT             8443
#define THING_NAME                  "Sebastian_CC3200_Board"

#define REQUEST_PATH                "/things/" THING_NAME "/shadow"
#define POSTHEADER                  "POST " REQUEST_PATH " HTTP/1.1\r\n"
#define HOSTHEADER                  "Host: " SERVER_NAME "\r\n"
#define CHEADER                     "Connection: close\r\n"
#define CTHEADER                    "Content-Type: application/json; charset=utf-8\r\n"
#define CLHEADER1                   "Content-Length: "
#define CLHEADER2                   "\r\n\r\n"

#define SYSCLKFREQ                  80000000ULL
#define SYSTICK_RELOAD_VAL          6400000UL
#define TICKS_TO_US(ticks) \
    ((((ticks) / SYSCLKFREQ) * 1000000ULL) + \
     ((((ticks) % SYSCLKFREQ) * 1000000ULL) / SYSCLKFREQ))

#define IR_GPIO_BASE                GPIOA1_BASE
#define IR_GPIO_PIN                 0x1

#define IR_LEADER_MIN_US            12500ULL
#define IR_LEADER_MAX_US            14500ULL
#define IR_BIT0_MIN_US              900ULL
#define IR_BIT0_MAX_US              1400ULL
#define IR_BIT1_MIN_US              1800ULL
#define IR_BIT1_MAX_US              2800ULL

#define IR_CODE_0                   0x02FDE0FFUL
#define IR_CODE_1                   0x02FD807FUL
#define IR_CODE_2                   0x02FD40BFUL
#define IR_CODE_3                   0x02FDC03FUL
#define IR_CODE_4                   0x02FD20DFUL
#define IR_CODE_5                   0x02FDA05FUL
#define IR_CODE_6                   0x02FD609FUL
#define IR_CODE_7                   0x02FDE01FUL
#define IR_CODE_8                   0x02FD10EFUL
#define IR_CODE_9                   0x02FD906FUL
#define IR_CODE_LAST                0x02FDE817UL
#define IR_CODE_MUTE                0x02FD08F7UL

#define IR_EVENT_QUEUE_LEN          16U
#define PIN_LEN                     4U
#define STATUS_MSG_LEN              28U
#define SENSOR_SAMPLE_INTERVAL_US   100000ULL
#define TRIGGER_COUNTDOWN_US        10000000ULL
#define MOTION_THRESHOLD            18
#define MOTION_HIT_LIMIT            3U

#define ACCEL_ADDR                  0x18
#define ACCEL_X_REG                 0x03
#define ACCEL_Y_REG                 0x05

#define BLACK                       0x0000
#define BLUE                        0x001F
#define GREEN                       0x07E0
#define CYAN                        0x07FF
#define RED                         0xF800
#define YELLOW                      0xFFE0
#define WHITE                       0xFFFF

typedef enum AppState {
    STATE_DISARMED = 0,
    STATE_ARMED,
    STATE_TRIGGERED,
    STATE_ALERT
} AppState;

#if defined(ccs) || defined(gcc)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif

static volatile uint32_t g_systick_wrap_count = 0;
static volatile uint64_t g_prev_edge_ticks = 0;
static volatile bool g_ir_frame_active = false;
static volatile uint32_t g_ir_bit_count = 0;
static volatile uint32_t g_ir_value = 0;
static volatile uint32_t g_ir_code_queue[IR_EVENT_QUEUE_LEN];
static volatile uint64_t g_ir_time_queue[IR_EVENT_QUEUE_LEN];
static volatile uint8_t g_ir_q_head = 0;
static volatile uint8_t g_ir_q_tail = 0;
static volatile uint32_t g_ir_q_overflow = 0;

static AppState g_app_state = STATE_DISARMED;
static char g_saved_pin[PIN_LEN + 1] = "";
static char g_input_pin[PIN_LEN + 1] = "";
static uint32_t g_input_len = 0U;
static char g_status_msg[STATUS_MSG_LEN] = "Enter PIN to arm";
static bool g_display_dirty = true;
static bool g_cloud_ready = false;

static int g_baseline_x = 0;
static int g_baseline_y = 0;
static int g_last_motion_x = 0;
static int g_last_motion_y = 0;
static uint32_t g_motion_hit_count = 0U;
static uint64_t g_last_sensor_sample_us = 0ULL;
static uint64_t g_trigger_start_us = 0ULL;
static uint32_t g_last_countdown_seconds = 0xFFFFFFFFUL;

static void BoardInit(void);
static int SetDeviceTime(void);
static int InitializeCloud(void);
static void InitializeSpiDisplay(void);
static void SysTickInit(void);
static void InitializeIrInterface(void);
static uint64_t GetNowTicks(void);
static uint64_t GetNowUs(void);
static void SysTickHandler(void);
static void GPIOA1IntHandler(void);
static void DecodeEdge(uint64_t pulse_width_us, uint64_t now_us);
static bool PopIrEvent(uint32_t *code, uint64_t *event_us);
static void ProcessIrCode(uint32_t code, uint64_t event_us);
static void HandleDigitKey(uint8_t digit);
static void HandleDeleteKey(void);
static void HandleConfirmKey(void);
static void ClearInputBuffer(void);
static bool InputMatchesSavedPin(void);
static void BuildPinDisplayText(char *buffer, size_t buffer_size, bool hide_digits);
static void SetStatusMessage(const char *msg);
static void DrawText(int x, int y, const char *text, unsigned int color,
                     unsigned int bg, unsigned char size);
static void DrawCenteredText(int y, const char *text, unsigned int color,
                             unsigned int bg, unsigned char size);
static void RenderScreen(uint64_t now_us, bool force);
static int ReadAccelerometerSample(int *x_value, int *y_value);
static int CaptureMotionBaseline(void);
static void UpdateMotionMonitor(uint64_t now_us);
static void EnterTriggeredState(uint64_t now_us, int motion_x, int motion_y);
static void TriggerAlert(void);
static void TransitionToDisarmed(const char *note);
static void ArmSystem(void);
static int AwsExchangeRequest(const char *request, char *response,
                              size_t response_size);
static int AwsPostStateUpdate(const char *mode, const char *note,
                              int motion_x, int motion_y);

static void BoardInit(void)
{
#ifndef USE_TIRTOS
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);
    PRCMCC3200MCUInit();
}

static int SetDeviceTime(void)
{
    long ret_val;

    UART_PRINT("[NET] Step 19: set RTC to %04d-%02d-%02d %02d:%02d:%02d UTC\n\r",
               YEAR, MONTH, DATE, HOUR, MINUTE, SECOND);

    g_time.tm_day = DATE;
    g_time.tm_mon = MONTH;
    g_time.tm_year = YEAR;
    g_time.tm_hour = HOUR;
    g_time.tm_min = MINUTE;
    g_time.tm_sec = SECOND;

    ret_val = sl_DevSet(SL_DEVICE_GENERAL_CONFIGURATION,
                        SL_DEVICE_GENERAL_CONFIGURATION_DATE_TIME,
                        sizeof(SlDateTime),
                        (unsigned char *)(&g_time));
    if (ret_val < 0) {
        UART_PRINT("[NET] sl_DevSet(date/time) failed: %ld\n\r", ret_val);
        ASSERT_ON_ERROR(ret_val);
    }
    UART_PRINT("[NET] RTC configured successfully\n\r");
    return SUCCESS;
}

static int InitializeCloud(void)
{
    long ret_val;

    g_app_config.host = SERVER_NAME;
    g_app_config.port = GOOGLE_DST_PORT;

    UART_PRINT("[NET] Cloud target host=%s port=%d thing=%s\n\r",
               SERVER_NAME, GOOGLE_DST_PORT, THING_NAME);

    ret_val = connectToAccessPoint();
    if (ret_val < 0) {
        UART_PRINT("[NET] connectToAccessPoint failed: %ld\n\r", ret_val);
        return ret_val;
    }

    ret_val = SetDeviceTime();
    if (ret_val < 0) {
        UART_PRINT("[NET] SetDeviceTime failed: %ld\n\r", ret_val);
        return ret_val;
    }

    g_cloud_ready = true;
    return SUCCESS;
}

static void InitializeSpiDisplay(void)
{
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI, PRCM_RUN_MODE_CLK);
    MAP_PRCMPeripheralReset(PRCM_GSPI);
    MAP_SPIReset(GSPI_BASE);

    MAP_SPIConfigSetExpClk(GSPI_BASE, MAP_PRCMPeripheralClockGet(PRCM_GSPI),
                           100000, SPI_MODE_MASTER, SPI_SUB_MODE_0,
                           (SPI_SW_CTRL_CS | SPI_4PIN_MODE | SPI_TURBO_OFF |
                            SPI_CS_ACTIVELOW | SPI_WL_8));

    MAP_SPIEnable(GSPI_BASE);
}

static void SysTickInit(void)
{
    MAP_SysTickPeriodSet(SYSTICK_RELOAD_VAL);
    MAP_SysTickIntRegister(SysTickHandler);
    MAP_SysTickIntEnable();
    MAP_SysTickEnable();
}

static void InitializeIrInterface(void)
{
    g_prev_edge_ticks = GetNowTicks();

    MAP_GPIOIntRegister(IR_GPIO_BASE, GPIOA1IntHandler);
    MAP_GPIOIntTypeSet(IR_GPIO_BASE, IR_GPIO_PIN, GPIO_FALLING_EDGE);
    MAP_GPIOIntClear(IR_GPIO_BASE, IR_GPIO_PIN);
    MAP_IntEnable(INT_GPIOA1);
    MAP_GPIOIntEnable(IR_GPIO_BASE, IR_GPIO_PIN);
}

static uint64_t GetNowTicks(void)
{
    uint32_t wraps_a;
    uint32_t wraps_b;
    uint32_t current;

    do {
        wraps_a = g_systick_wrap_count;
        current = MAP_SysTickValueGet();
        wraps_b = g_systick_wrap_count;
    } while (wraps_a != wraps_b);

    return ((uint64_t)wraps_a * (uint64_t)SYSTICK_RELOAD_VAL) +
           ((uint64_t)SYSTICK_RELOAD_VAL - (uint64_t)current);
}

static uint64_t GetNowUs(void)
{
    return TICKS_TO_US(GetNowTicks());
}

static void SysTickHandler(void)
{
    g_systick_wrap_count++;
}

static void DecodeEdge(uint64_t pulse_width_us, uint64_t now_us)
{
    uint8_t next_head;

    if ((pulse_width_us >= IR_LEADER_MIN_US) &&
        (pulse_width_us <= IR_LEADER_MAX_US)) {
        g_ir_frame_active = true;
        g_ir_bit_count = 0U;
        g_ir_value = 0U;
        return;
    }

    if (!g_ir_frame_active) {
        return;
    }

    if ((pulse_width_us >= IR_BIT0_MIN_US) &&
        (pulse_width_us <= IR_BIT0_MAX_US)) {
        g_ir_value <<= 1;
        g_ir_bit_count++;
    } else if ((pulse_width_us >= IR_BIT1_MIN_US) &&
               (pulse_width_us <= IR_BIT1_MAX_US)) {
        g_ir_value = (g_ir_value << 1) | 1U;
        g_ir_bit_count++;
    } else {
        g_ir_frame_active = false;
        g_ir_bit_count = 0U;
        g_ir_value = 0U;
        return;
    }

    if (g_ir_bit_count == 32U) {
        g_ir_frame_active = false;
        next_head = (uint8_t)((g_ir_q_head + 1U) % IR_EVENT_QUEUE_LEN);

        if (next_head != g_ir_q_tail) {
            g_ir_code_queue[g_ir_q_head] = g_ir_value;
            g_ir_time_queue[g_ir_q_head] = now_us;
            g_ir_q_head = next_head;
        } else {
            g_ir_q_overflow++;
        }
    }
}

static void GPIOA1IntHandler(void)
{
    unsigned long status;
    uint64_t now_ticks;
    uint64_t delta_ticks;

    status = MAP_GPIOIntStatus(IR_GPIO_BASE, true);
    MAP_GPIOIntClear(IR_GPIO_BASE, status);

    now_ticks = GetNowTicks();
    if (g_prev_edge_ticks == 0ULL) {
        g_prev_edge_ticks = now_ticks;
        return;
    }

    delta_ticks = now_ticks - g_prev_edge_ticks;
    g_prev_edge_ticks = now_ticks;
    DecodeEdge(TICKS_TO_US(delta_ticks), TICKS_TO_US(now_ticks));
}

static bool PopIrEvent(uint32_t *code, uint64_t *event_us)
{
    bool has_event = false;

    MAP_IntMasterDisable();
    if (g_ir_q_tail != g_ir_q_head) {
        *code = g_ir_code_queue[g_ir_q_tail];
        *event_us = g_ir_time_queue[g_ir_q_tail];
        g_ir_q_tail = (uint8_t)((g_ir_q_tail + 1U) % IR_EVENT_QUEUE_LEN);
        has_event = true;
    }
    MAP_IntMasterEnable();

    return has_event;
}

static void ClearInputBuffer(void)
{
    memset(g_input_pin, 0, sizeof(g_input_pin));
    g_input_len = 0U;
    g_display_dirty = true;
}

static bool InputMatchesSavedPin(void)
{
    return (g_input_len == PIN_LEN) &&
           (memcmp(g_input_pin, g_saved_pin, PIN_LEN) == 0);
}

static void SetStatusMessage(const char *msg)
{
    strncpy(g_status_msg, msg, STATUS_MSG_LEN - 1U);
    g_status_msg[STATUS_MSG_LEN - 1U] = '\0';
    g_display_dirty = true;
}

static void BuildPinDisplayText(char *buffer, size_t buffer_size, bool hide_digits)
{
    char pin_view[PIN_LEN + 1];
    uint32_t i;

    for (i = 0U; i < PIN_LEN; i++) {
        if (i < g_input_len) {
            pin_view[i] = hide_digits ? '*' : g_input_pin[i];
        } else {
            pin_view[i] = '_';
        }
    }
    pin_view[PIN_LEN] = '\0';

    snprintf(buffer, buffer_size, "PIN: %s", pin_view);
}

static void DrawText(int x, int y, const char *text, unsigned int color,
                     unsigned int bg, unsigned char size)
{
    size_t i;
    int cursor_x = x;

    for (i = 0U; text[i] != '\0'; i++) {
        drawChar(cursor_x, y, (unsigned char)text[i], color, bg, size);
        cursor_x += 6 * size;
    }
}

static void DrawCenteredText(int y, const char *text, unsigned int color,
                             unsigned int bg, unsigned char size)
{
    int width;
    int x;

    width = (int)strlen(text) * 6 * size;
    x = (SSD1351WIDTH - width) / 2;
    if (x < 0) {
        x = 0;
    }

    DrawText(x, y, text, color, bg, size);
}

static void RenderScreen(uint64_t now_us, bool force)
{
    char pin_line[20];
    char footer[20];
    char line2[24];
    unsigned int bg = BLACK;
    unsigned int fg = WHITE;
    uint32_t seconds_remaining = 0U;
    uint64_t elapsed_us = 0ULL;

    if (!force && !g_display_dirty) {
        if (g_app_state != STATE_TRIGGERED) {
            return;
        }

        elapsed_us = now_us - g_trigger_start_us;
        if (elapsed_us >= TRIGGER_COUNTDOWN_US) {
            seconds_remaining = 0U;
        } else {
            seconds_remaining = (uint32_t)
                ((TRIGGER_COUNTDOWN_US - elapsed_us + 999999ULL) / 1000000ULL);
        }
        if (seconds_remaining == g_last_countdown_seconds) {
            return;
        }
    }

    if (g_app_state == STATE_TRIGGERED) {
        elapsed_us = now_us - g_trigger_start_us;
        if (elapsed_us >= TRIGGER_COUNTDOWN_US) {
            seconds_remaining = 0U;
        } else {
            seconds_remaining = (uint32_t)
                ((TRIGGER_COUNTDOWN_US - elapsed_us + 999999ULL) / 1000000ULL);
        }
        g_last_countdown_seconds = seconds_remaining;
    } else {
        g_last_countdown_seconds = 0xFFFFFFFFUL;
    }

    BuildPinDisplayText(pin_line, sizeof(pin_line), g_app_state != STATE_DISARMED);
    snprintf(footer, sizeof(footer), "Cloud: %s",
             g_cloud_ready ? "ready" : "error");

    if (g_app_state == STATE_ALERT) {
        bg = RED;
        fg = WHITE;
    }

    fillScreen(bg);

    switch (g_app_state) {
        case STATE_DISARMED:
            DrawCenteredText(6, "DISARMED", CYAN, bg, 2);
            DrawText(4, 36, "Enter 4 digits", fg, bg, 1);
            DrawText(4, 52, pin_line, YELLOW, bg, 2);
            DrawText(4, 82, "MUTE arm", fg, bg, 1);
            DrawText(4, 94, "LAST delete", fg, bg, 1);
            break;

        case STATE_ARMED:
            DrawCenteredText(6, "ARMED", GREEN, bg, 2);
            DrawText(4, 36, "Move board to trigger", fg, bg, 1);
            DrawText(4, 52, pin_line, CYAN, bg, 2);
            DrawText(4, 82, "Enter PIN + MUTE", fg, bg, 1);
            DrawText(4, 94, "LAST delete", fg, bg, 1);
            break;

        case STATE_TRIGGERED:
            DrawCenteredText(6, "TRIGGERED", YELLOW, bg, 2);
            snprintf(line2, sizeof(line2), "Disarm in %lus",
                     (unsigned long)seconds_remaining);
            DrawText(4, 36, line2, fg, bg, 1);
            DrawText(4, 52, pin_line, CYAN, bg, 2);
            DrawText(4, 82, "PIN + MUTE cancels", fg, bg, 1);
            DrawText(4, 94, "LAST delete", fg, bg, 1);
            break;

        case STATE_ALERT:
        default:
            DrawCenteredText(6, "ALERT SENT", fg, bg, 2);
            DrawText(4, 36, "Check AWS/SNS alert", fg, bg, 1);
            DrawText(4, 52, pin_line, WHITE, bg, 2);
            DrawText(4, 82, "PIN + MUTE resets", fg, bg, 1);
            DrawText(4, 94, "LAST delete", fg, bg, 1);
            break;
    }

    DrawText(4, 108, g_status_msg, fg, bg, 1);
    DrawText(4, 120, footer, fg, bg, 1);

    g_display_dirty = false;
}

static int ReadAccelerometerSample(int *x_value, int *y_value)
{
    int ret_val;
    unsigned char reg;
    unsigned char sample;

    reg = ACCEL_X_REG;
    ret_val = I2C_IF_Write(ACCEL_ADDR, &reg, 1U, 0U);
    if (ret_val < 0) {
        return ret_val;
    }

    ret_val = I2C_IF_Read(ACCEL_ADDR, &sample, 1U);
    if (ret_val < 0) {
        return ret_val;
    }
    *x_value = (int)((int8_t)sample);

    reg = ACCEL_Y_REG;
    ret_val = I2C_IF_Write(ACCEL_ADDR, &reg, 1U, 0U);
    if (ret_val < 0) {
        return ret_val;
    }

    ret_val = I2C_IF_Read(ACCEL_ADDR, &sample, 1U);
    if (ret_val < 0) {
        return ret_val;
    }
    *y_value = (int)((int8_t)sample);

    return SUCCESS;
}

static int CaptureMotionBaseline(void)
{
    long sum_x = 0;
    long sum_y = 0;
    int sample_x;
    int sample_y;
    int ret_val;
    uint32_t i;

    for (i = 0U; i < 8U; i++) {
        ret_val = ReadAccelerometerSample(&sample_x, &sample_y);
        if (ret_val < 0) {
            return ret_val;
        }

        sum_x += sample_x;
        sum_y += sample_y;
        MAP_UtilsDelay(40000);
    }

    g_baseline_x = (int)(sum_x / 8L);
    g_baseline_y = (int)(sum_y / 8L);
    return SUCCESS;
}

static void EnterTriggeredState(uint64_t now_us, int motion_x, int motion_y)
{
    g_app_state = STATE_TRIGGERED;
    g_trigger_start_us = now_us;
    g_last_motion_x = motion_x;
    g_last_motion_y = motion_y;
    g_motion_hit_count = 0U;
    ClearInputBuffer();
    SetStatusMessage("Motion detected");
}

static int AwsExchangeRequest(const char *request, char *response,
                              size_t response_size)
{
    int ret_val;
    int tls_socket;

    if (!g_cloud_ready) {
        return FAILURE;
    }

    tls_socket = tls_connect();
    if (tls_socket < 0) {
        g_cloud_ready = false;
        return tls_socket;
    }

    ret_val = sl_Send(tls_socket, request, strlen(request), 0);
    if (ret_val < 0) {
        sl_Close(tls_socket);
        g_cloud_ready = false;
        return ret_val;
    }

    ret_val = sl_Recv(tls_socket, response, response_size - 1U, 0);
    if (ret_val < 0) {
        sl_Close(tls_socket);
        g_cloud_ready = false;
        return ret_val;
    }

    response[ret_val] = '\0';
    sl_Close(tls_socket);

    if ((strstr(response, "HTTP/1.1 200") == 0) &&
        (strstr(response, "HTTP/1.0 200") == 0) &&
        (strstr(response, "HTTP/1.1 204") == 0)) {
        return FAILURE;
    }

    return SUCCESS;
}

static int AwsPostStateUpdate(const char *mode, const char *note,
                              int motion_x, int motion_y)
{
    char payload[256];
    char request[768];
    char response[1460];
    char content_length[16];
    char *cursor;
    unsigned long uptime_sec;
    int data_length;

    uptime_sec = (unsigned long)(GetNowUs() / 1000000ULL);

    snprintf(payload, sizeof(payload),
             "{\"state\":{\"reported\":{\"mode\":\"%s\",\"note\":\"%s\","
             "\"motion_x\":%d,\"motion_y\":%d,\"uptime_sec\":%lu}}}\r\n",
             mode, note, motion_x, motion_y, uptime_sec);

    data_length = strlen(payload);
    cursor = request;

    strcpy(cursor, POSTHEADER);
    cursor += strlen(POSTHEADER);
    strcpy(cursor, HOSTHEADER);
    cursor += strlen(HOSTHEADER);
    strcpy(cursor, CHEADER);
    cursor += strlen(CHEADER);
    strcpy(cursor, CTHEADER);
    cursor += strlen(CTHEADER);
    strcpy(cursor, CLHEADER1);
    cursor += strlen(CLHEADER1);
    sprintf(content_length, "%d", data_length);
    strcpy(cursor, content_length);
    cursor += strlen(content_length);
    strcpy(cursor, CLHEADER2);
    cursor += strlen(CLHEADER2);
    strcpy(cursor, payload);

    return AwsExchangeRequest(request, response, sizeof(response));
}

static void TransitionToDisarmed(const char *note)
{
    int ret_val;

    g_app_state = STATE_DISARMED;
    g_motion_hit_count = 0U;
    g_trigger_start_us = 0ULL;
    g_last_motion_x = 0;
    g_last_motion_y = 0;
    ClearInputBuffer();

    ret_val = AwsPostStateUpdate("DISARMED", note, 0, 0);
    if (ret_val == SUCCESS) {
        SetStatusMessage("System disarmed");
    } else {
        SetStatusMessage("Disarmed; cloud failed");
    }
}

static void TriggerAlert(void)
{
    int ret_val;

    g_app_state = STATE_ALERT;
    ClearInputBuffer();

    ret_val = AwsPostStateUpdate("ALERT", "motion threshold exceeded",
                                 g_last_motion_x, g_last_motion_y);
    if (ret_val == SUCCESS) {
        SetStatusMessage("Alert posted to AWS");
    } else {
        SetStatusMessage("Alert local only");
    }
}

static void ArmSystem(void)
{
    int ret_val;

    ret_val = CaptureMotionBaseline();
    if (ret_val < 0) {
        SetStatusMessage("Accelerometer read failed");
        return;
    }

    memcpy(g_saved_pin, g_input_pin, PIN_LEN);
    g_saved_pin[PIN_LEN] = '\0';
    g_app_state = STATE_ARMED;
    g_motion_hit_count = 0U;
    g_last_sensor_sample_us = 0ULL;
    ClearInputBuffer();

    ret_val = AwsPostStateUpdate("ARMED", "system armed", 0, 0);
    if (ret_val == SUCCESS) {
        SetStatusMessage("System armed");
    } else {
        SetStatusMessage("Armed; cloud failed");
    }
}

static void UpdateMotionMonitor(uint64_t now_us)
{
    int sample_x;
    int sample_y;
    int diff_x;
    int diff_y;

    if (g_app_state != STATE_ARMED) {
        return;
    }

    if ((now_us - g_last_sensor_sample_us) < SENSOR_SAMPLE_INTERVAL_US) {
        return;
    }
    g_last_sensor_sample_us = now_us;

    if (ReadAccelerometerSample(&sample_x, &sample_y) < 0) {
        SetStatusMessage("Accelerometer read failed");
        return;
    }

    diff_x = abs(sample_x - g_baseline_x);
    diff_y = abs(sample_y - g_baseline_y);

    if ((diff_x > MOTION_THRESHOLD) || (diff_y > MOTION_THRESHOLD)) {
        g_motion_hit_count++;
        g_last_motion_x = diff_x;
        g_last_motion_y = diff_y;
    } else {
        g_motion_hit_count = 0U;
    }

    if (g_motion_hit_count >= MOTION_HIT_LIMIT) {
        EnterTriggeredState(now_us, diff_x, diff_y);
    }
}

static void HandleDigitKey(uint8_t digit)
{
    if (g_input_len >= PIN_LEN) {
        SetStatusMessage("PIN already 4 digits");
        return;
    }

    g_input_pin[g_input_len++] = (char)('0' + digit);
    g_input_pin[g_input_len] = '\0';
    g_display_dirty = true;
}

static void HandleDeleteKey(void)
{
    if (g_input_len == 0U) {
        return;
    }

    g_input_len--;
    g_input_pin[g_input_len] = '\0';
    g_display_dirty = true;
}

static void HandleConfirmKey(void)
{
    if (g_input_len != PIN_LEN) {
        SetStatusMessage("Enter 4 digits first");
        return;
    }

    switch (g_app_state) {
        case STATE_DISARMED:
            ArmSystem();
            break;

        case STATE_ARMED:
            if (InputMatchesSavedPin()) {
                TransitionToDisarmed("manual disarm");
            } else {
                ClearInputBuffer();
                SetStatusMessage("Invalid disarm PIN");
            }
            break;

        case STATE_TRIGGERED:
            if (InputMatchesSavedPin()) {
                TransitionToDisarmed("trigger cancelled");
            } else {
                ClearInputBuffer();
                SetStatusMessage("Invalid cancel PIN");
            }
            break;

        case STATE_ALERT:
        default:
            if (InputMatchesSavedPin()) {
                TransitionToDisarmed("alert reset");
            } else {
                ClearInputBuffer();
                SetStatusMessage("Invalid reset PIN");
            }
            break;
    }
}

static void ProcessIrCode(uint32_t code, uint64_t event_us)
{
    UNUSED(event_us);

    switch (code) {
        case IR_CODE_0: HandleDigitKey(0U); break;
        case IR_CODE_1: HandleDigitKey(1U); break;
        case IR_CODE_2: HandleDigitKey(2U); break;
        case IR_CODE_3: HandleDigitKey(3U); break;
        case IR_CODE_4: HandleDigitKey(4U); break;
        case IR_CODE_5: HandleDigitKey(5U); break;
        case IR_CODE_6: HandleDigitKey(6U); break;
        case IR_CODE_7: HandleDigitKey(7U); break;
        case IR_CODE_8: HandleDigitKey(8U); break;
        case IR_CODE_9: HandleDigitKey(9U); break;
        case IR_CODE_LAST: HandleDeleteKey(); break;
        case IR_CODE_MUTE: HandleConfirmKey(); break;
        default:
            UART_PRINT("Unknown IR code: 0x%08lx\n\r", (unsigned long)code);
            break;
    }
}

void main(void)
{
    long ret_val;
    uint32_t ir_code;
    uint64_t ir_time_us;
    uint32_t dropped_ir_events = 0U;
    uint64_t now_us;

    BoardInit();
    PinMuxConfig();
    InitTerm();
    ClearTerm();

    UART_PRINT("\n\r%s\n\r", APPLICATION_VERSION);
    UART_PRINT("Security Node\n\r");

    SysTickInit();
    InitializeSpiDisplay();

    ret_val = I2C_IF_Open(I2C_MASTER_MODE_FST);
    if (ret_val < 0) {
        UART_PRINT("I2C open failed: %ld\n\r", ret_val);
        LOOP_FOREVER();
    }

    Adafruit_Init();
    fillScreen(BLACK);
    UART_PRINT("[BOOT] OLED init complete\n\r");
    SetStatusMessage("Booting");
    RenderScreen(GetNowUs(), true);

    SetStatusMessage("Starting cloud init");
    RenderScreen(GetNowUs(), true);
    ret_val = InitializeCloud();
    if (ret_val < 0) {
        UART_PRINT("Cloud init failed: %ld\n\r", ret_val);
        SetStatusMessage("Cloud init failed");
    } else {
        SetStatusMessage("Cloud connected");
    }

    InitializeIrInterface();

    RenderScreen(GetNowUs(), true);

    while (1) {
        while (PopIrEvent(&ir_code, &ir_time_us)) {
            ProcessIrCode(ir_code, ir_time_us);
        }

        now_us = GetNowUs();

        UpdateMotionMonitor(now_us);

        if ((g_app_state == STATE_TRIGGERED) &&
            ((now_us - g_trigger_start_us) >= TRIGGER_COUNTDOWN_US)) {
            TriggerAlert();
        }

        RenderScreen(now_us, false);

        if (g_ir_q_overflow != dropped_ir_events) {
            dropped_ir_events = g_ir_q_overflow;
            UART_PRINT("Warning: dropped IR events: %lu\n\r",
                       (unsigned long)dropped_ir_events);
        }
    }
}
